	function image1(w)
	{
		var pic=document.getElementById('image1');
		if (w==1)
		{
			pic.src="1.jpg";
		}
		else if (w==2)
		{
			pic.src="2.jpg";
		}
	}
	function image2(w)
	{
		var pic=document.getElementById('image2');
		if (w==1)
		{
			pic.src="3.jpg";
		}
		else if (w==2)
		{
			pic.src="4.jpg";
		}
	}
	function image3(w)
	{
		var pic=document.getElementById('image3');
		if (w==1)
		{
			pic.src="5.jpg";
		}
		else if (w==2)
		{
			pic.src="6.jpg";
		}
	}
	function image4(w)
	{
		var pic=document.getElementById('image4');
		if (w==1)
		{
			pic.src="7.jpg";
		}
		else if (w==2)
		{
			pic.src="8.jpg";
		}
	}
	function image5(w)
	{
		var pic=document.getElementById('image5');
		if (w==1)
		{
			pic.src="9.jpg";
		}
		else if (w==2)
		{
			pic.src="10.jpg";
		}
	}
	function image6(w)
	{
		var pic=document.getElementById('image6');
		if (w==1)
		{
			pic.src="11.jpg";
		}
		else if (w==2)
		{
			pic.src="12.jpg";
		}
	}
	function image7(w)
	{
		var pic=document.getElementById('image7');
		if (w==1)
		{
			pic.src="13.jpg";
		}
		else if (w==2)
		{
			pic.src="14.jpg";
		}
	}
	function image8(w)
	{
		var pic=document.getElementById('image8');
		if (w==1)
		{
			pic.src="15.jpg";
		}
		else if (w==2)
		{
			pic.src="16.jpg";
		}
	}
	function image9(w)
	{
		var pic=document.getElementById('image9');
		if (w==1)
		{
			pic.src="17.jpg";
		}
		else if (w==2)
		{
			pic.src="18.jpg";
		}
	}
	function image10(w)
	{
		var pic=document.getElementById('image10');
		if (w==1)
		{
			pic.src="19.jpg";
		}
		else if (w==2)
		{
			pic.src="20.jpg";
		}
	}